package admin;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import javax.swing.JScrollPane;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class ProductManagement {
	private JFrame frame;
	private JTable table;
	private JTextField t1;
	private JTextField t2;
	private JTextField t3;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProductManagement window = new ProductManagement();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public ProductManagement() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 956, 552);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setUndecorated(true);		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(84, 214, 133));
		panel.setForeground(new Color(255, 147, 147));
		panel.setBounds(0, 0, 260, 542);
		frame.getContentPane().add(panel);
		panel.setLayout(null);	
		JLabel lblNewLabel_2 = new JLabel("Prod Id");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2.setBounds(21, 55, 59, 37);
		panel.add(lblNewLabel_2);	
		t1 = new JTextField();
		t1.setBounds(116, 55, 134, 33);
		panel.add(t1);
		t1.setColumns(10);	
		JLabel lblNewLabel_2_1 = new JLabel("Prod Name");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_1.setBounds(21, 125, 59, 41);
		panel.add(lblNewLabel_2_1);
		t2 = new JTextField();
		t2.setColumns(10);
		t2.setBounds(116, 125, 134, 37);
		panel.add(t2);
		JLabel lblNewLabel_2_1_1 = new JLabel("Prod Price");
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblNewLabel_2_1_1.setBounds(21, 202, 59, 41);
		panel.add(lblNewLabel_2_1_1);
		
		t3 = new JTextField();
		t3.setColumns(10);
		t3.setBounds(116, 202, 134, 37);
		panel.add(t3);
		
		JButton btnNewButton = new JButton("SHOW");
		btnNewButton.setBounds(21, 274, 85, 21);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("ADD");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL","system","password");
					Statement stmt=con.createStatement();
					String pid=t1.getText();
					String pname=t2.getText();
					String pprice= t3.getText();
					String insqr="insert into product1 values('"+pid+"' , '"+pname+"','"+pprice+"')";
					stmt.execute(insqr);
					System.out.println("Product added successfully");
					JOptionPane.showMessageDialog(null,"Product added successfully");
					t1.setText("");
					t2.setText("");
					t3.setText("");
					con.close();		
				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}
			}
			
		});
		btnNewButton_1.setBounds(165, 274, 85, 21);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("DELETE");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {
			            Class.forName("oracle.jdbc.driver.OracleDriver");
			            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL", "system", "password");
			            Statement stmt = con.createStatement();
			            
			          
			            String pidToDelete = t1.getText();
			           
			            
			            String delQuery = "DELETE FROM product1 WHERE prod_id = '" + pidToDelete + "'";
			            int rowsAffected = stmt.executeUpdate(delQuery);
			            
			            if (rowsAffected > 0) {
			                System.out.println("Product deleted successfully");
			                JOptionPane.showMessageDialog(null, "Product deleted successfully");
			            } else {
			                System.out.println("Product with ID " + pidToDelete + " not found");
			                JOptionPane.showMessageDialog(null, "Product with ID " + pidToDelete + " not found");
			            }
			            
			            con.close();
			        } catch (Exception e1) {
			            System.out.println(e1);
			        }
			}
		});
		btnNewButton_1_1.setBounds(21, 344, 85, 21);
		panel.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_1_1 = new JButton("EDIT");
		btnNewButton_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{	
					  Class.forName("oracle.jdbc.driver.OracleDriver");
			            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL","system","password");
			            Statement stmt=con.createStatement();      
			            String pid = t1.getText();
			            String pname = t2.getText();
			            String pprice = t3.getText();
			            DefaultTableModel dtm=(DefaultTableModel)table.getModel();
			            dtm.setValueAt(pid, table.getSelectedRow(), 0);
			            dtm.setValueAt(pname, table.getSelectedRow(), 1);
			            dtm.setValueAt(pprice, table.getSelectedRow(), 2);
			            String updateQuery = "UPDATE product1 SET prod_name = '" + pname + "', prod_price = '" + pprice + "' WHERE prod_id = '" + pid + "'";        
			            int rowsUpdated = stmt.executeUpdate(updateQuery);
			            if (rowsUpdated > 0) {
			                System.out.println("Product updated successfully");
			                JOptionPane.showMessageDialog(null,"Product updated successfully");
			            } else {
			                System.out.println("No product found with ID: " + pid);
			                JOptionPane.showMessageDialog(null,"No product found with ID: " + pid);
			            }
			            
			            
			            t1.setText("");
			            t2.setText("");
			            t3.setText("");
			            
			            con.close();
			        } catch(Exception e1) {
			            System.out.println(e1);
			        }
			    }
				
			
		});
		btnNewButton_1_1_1.setBounds(165, 344, 85, 21);
		panel.add(btnNewButton_1_1_1);
		
		JButton btnNewButton_1_1_2 = new JButton("CANCEL");
		btnNewButton_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				admindashboard ab=new admindashboard();
				ab.setVisible(true);
			}
		});
		btnNewButton_1_1_2.setBounds(92, 390, 85, 21);
		panel.add(btnNewButton_1_1_2);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL","system","password");
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery("select PROD_ID,PROD_NAME, PROD_PRICE from product1");
					table.setModel(DbUtils.resultSetToTableModel(rs));
					
					con.close();
					
					
				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(363, 99, 414, 211);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel dtm=(DefaultTableModel)table.getModel();
				String pid=(String)dtm.getValueAt(table.getSelectedRow(), 0);
				String pnm=(String)dtm.getValueAt(table.getSelectedRow(), 1);
				String pprice=(String)dtm.getValueAt(table.getSelectedRow(), 2);
				t1.setText(pid);
				t2.setText(pnm);
				t3.setText(pprice);
				
		
			}
		});
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"PROD_ID", "PROD_NAME", "PROD_PRICE"
			}
		));
		
		JLabel lblNewLabel_1 = new JLabel("PRODUCT  MANAGEMENT");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_1.setBounds(447, 38, 240, 31);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("X");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel.setBounds(930, 10, 45, 13);
		frame.getContentPane().add(lblNewLabel);
	}

	public void setVisible(boolean b) {
		frame.setVisible(b);
	}
}
