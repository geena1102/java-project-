package admin;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class admindashboard {
	private JFrame frame;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admindashboard window = new admindashboard();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public admindashboard() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 787, 535);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setUndecorated(true);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(84, 214, 133));
		panel.setBounds(0, 0, 787, 63);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		JLabel lblNewLabel = new JLabel("ADMIN DASHBOARD");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel.setBounds(10, 10, 162, 43);
		panel.add(lblNewLabel);		
		JLabel lblNewLabel_1 = new JLabel("X");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(863, 10, 45, 13);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Logout");
		lblNewLabel_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				alogin a=new alogin();
				a.setVisible(true);
			}
		});
		lblNewLabel_1_1.setBounds(714, 25, 73, 13);
		panel.add(lblNewLabel_1_1);
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_1_1.setBackground(Color.WHITE);	
		JButton btnNewButton = new JButton("Product Management");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProductManagement pm=new ProductManagement();
				pm.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnNewButton.setBounds(344, 189, 161, 63);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnProductDetails = new JButton("Product Details");
		btnProductDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				productdetails pd=new productdetails();
				pd.setVisible(true);
			}
		});
		btnProductDetails.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnProductDetails.setBounds(344, 77, 161, 57);
		frame.getContentPane().add(btnProductDetails);
		
		JButton btnUserDetails = new JButton("User Details");
		btnUserDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userdetails u=new userdetails();
				u.setVisible(true);
			}
		});
		btnUserDetails.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnUserDetails.setBounds(344, 304, 165, 68);
		frame.getContentPane().add(btnUserDetails);
		
		JButton btnUserDetails_1 = new JButton("User Details");
		btnUserDetails_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnUserDetails_1.setBounds(344, 304, 165, 68);
		frame.getContentPane().add(btnUserDetails_1);
		
		JButton btnOrderDetails = new JButton("Order Details");
		btnOrderDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OrderDetailss od=new OrderDetailss();
				od.setVisible(true);			}
		});
		btnOrderDetails.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnOrderDetails.setBounds(340, 419, 165, 68);
		frame.getContentPane().add(btnOrderDetails);
	}

	public void setVisible(boolean b) {
		frame.setVisible(b);
		
	}
}
