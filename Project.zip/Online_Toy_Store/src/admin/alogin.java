package admin;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import dashboard.frontpage;

//import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class alogin {
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					alogin window = new alogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public alogin() {
		initialize();
	}
	 public boolean validateLogin() {
	        String username = textField.getText();
	        String password = textField_1.getText();

	        if (username.isEmpty()) {
	            JOptionPane.showMessageDialog(frame, "Please enter username");
	            return false;
	        }

	        if (password.isEmpty()) {
	            JOptionPane.showMessageDialog(frame, "Please enter password");
	            return false;
	        }
	        try {
	            Class.forName("oracle.jdbc.driver.OracleDriver");
	            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL", "system", "password");
	            PreparedStatement pst = con.prepareStatement("select * from admin where uname=? and password=?");
	            pst.setString(1, username);
	            pst.setString(2, password);

	            ResultSet rs = pst.executeQuery();
	            if (rs.next()) {
	                JOptionPane.showMessageDialog(frame, "Login successful");
	               admindashboard db = new admindashboard();
	                db.setVisible(true);
	                dispose();
	            } else {
	                JOptionPane.showMessageDialog(frame, "Invalid username or password");
	            }
	            rs.close();
	            pst.close();
	            con.close();
	           
	        } catch (Exception ex) {
	            System.out.println(ex);
	        } 
	       
	        return true;
	    }
	    public void dispose() {

	    }
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 846, 548);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setUndecorated(true);
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(30, 225, 206));
		panel_1.setBounds(374, 10, 395, 593);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		JLabel lblNewLabel_1 = new JLabel("LOGIN");
		lblNewLabel_1.setFont(new Font("Bodoni MT Condensed", Font.BOLD, 20));
		lblNewLabel_1.setBounds(570, 36, 45, 13);
		panel_1.add(lblNewLabel_1);	
		JLabel lblNewLabel_2 = new JLabel("Username");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(444, 104, 79, 28);
		panel_1.add(lblNewLabel_2);	
		textField = new JTextField();
		textField.setBounds(615, 107, 147, 36);
		panel_1.add(textField);
		textField.setColumns(10);
		JPanel panel = new JPanel();
		panel_1.add(panel);
		panel.setBackground(new Color(60, 192, 196));
		panel.setForeground(new Color(0, 255, 64));
		panel.setBounds(0, 0, 366, 593);
		panel.setLayout(null);
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(alogin.class.getResource("/icon/e22ed330d027db81cd964bab58d8d2c8-removebg-preview.png")));	
		lblNewLabel.setBounds(-87, 37, 469, 428);
		panel.add(lblNewLabel);
		JLabel lblNewLabel_4 = new JLabel("WELCOME ADMIN");
		lblNewLabel_4.setFont(new Font("Sylfaen", Font.BOLD, 15));
		lblNewLabel_4.setBounds(10, 10, 297, 47);
		panel.add(lblNewLabel_4);	
		JLabel lblNewLabel_3 = new JLabel("Password");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3.setBounds(444, 204, 79, 28);
		panel_1.add(lblNewLabel_3);	
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {		
				 validateLogin();
			}
		});
		btnNewButton.setBackground(new Color(32, 223, 223));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnNewButton.setBackground(new Color(30, 225, 206));
		btnNewButton.setBounds(542, 289, 85, 21);
		panel_1.add(btnNewButton);
		textField_1 = new JTextField();
		textField_1.setBounds(615, 211, 147, 28);
		panel_1.add(textField_1);
		textField_1.setColumns(10);
		JLabel lblNewLabel_5 = new JLabel("X");
		lblNewLabel_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_5.setBounds(818, 10, 45, 13);
		panel_1.add(lblNewLabel_5);
		JLabel lblNewLabel_6 = new JLabel("New label");
		lblNewLabel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frontpage f=new frontpage();
				f.setVisible(true);
			}
		});
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\geena\\Downloads\\360_F_370150011_qNBM8qsN7Vk77Mgo-removebg-preview.png"));
		lblNewLabel_6.setBounds(364, 0, 45, 37);
		panel_1.add(lblNewLabel_6);
	
	}

	public void setVisible(boolean b) {
		frame.setVisible(b);	
	}
}
