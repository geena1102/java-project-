package admin;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class OrderDetailss {
    private JFrame frame;
    private JScrollPane scrollPane;
    private JTable table;
    private DefaultTableModel model;
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1522:ORCL";
    private static final String DB_USER = "system";
    private static final String DB_PASSWORD = "password";
    private JButton btnNewButton;
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	OrderDetailss window = new OrderDetailss();

                    window.frame.setVisible(true);

                } catch (Exception e) {

                    e.printStackTrace();

                }

            }

        });

    }
    public OrderDetailss() {

        initialize();

        fetchDataAndPopulateTable();
    }

    private void initialize() {
       frame = new JFrame();
        frame.setBackground(new Color(128, 128, 128));
        frame.setBounds(100, 100, 934, 712);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        JPanel panel = new JPanel();
        panel.setBackground(new Color(128, 128, 128));
        panel.setBounds(10, 65, 900, 600);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 10, 880, 635);
        panel.add(scrollPane);
        table = new JTable();
        model = new DefaultTableModel(
            new Object[][] {},
            new String[] { "Order ID",  "Product Name", "Price", "Customer Name", "Address" }
        );
        table.setModel(model);
        scrollPane.setViewportView(table);
        JLabel lblNewLabel = new JLabel("Order Details");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel.setBounds(359, 10, 203, 26);
        frame.getContentPane().add(lblNewLabel);
        btnNewButton = new JButton("Back");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		admindashboard ad=new admindashboard();
        		ad.setVisible(true);
        	}
        });
        btnNewButton.setBounds(825, 43, 85, 21);
        frame.getContentPane().add(btnNewButton);
        frame.setUndecorated(true);
    }
    private void fetchDataAndPopulateTable() {
        try {
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            String query = "SELECT od.order_id, p.prod_name, p.prod_price, c.cust_name, c.cust_add " +
                           "FROM orders od " +
                           "INNER JOIN product1 p ON od.prod_id = p.prod_id " +
                           "INNER JOIN customer1 c ON od.user_id = c.cust_id";
            System.out.println(query);
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Object[] row = {
                    resultSet.getString("order_id"),                   
                    resultSet.getString("prod_name"),
                    resultSet.getString("prod_price"),
                    resultSet.getString("cust_name"),
                    resultSet.getString("cust_add")
                };
                model.addRow(row);
            }
            resultSet.close();
            statement.close();
            conn.close();
        } catch (SQLException e) {

            e.printStackTrace();
        }

    }
	public void setVisible(boolean b) {
		frame.setVisible(b);	
	}

}