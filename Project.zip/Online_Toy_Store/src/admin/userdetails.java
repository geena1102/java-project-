package admin;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import  net.proteanit.sql.DbUtils;
public class userdetails {
	private JFrame frame;
	private JTable table;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					userdetails window = new userdetails();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public userdetails() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 886, 593);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setUndecorated(true);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(84, 214, 133));
		panel.setBounds(0, 10, 872, 535);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		JLabel lblNewLabel = new JLabel("USER DETAILS");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel.setBounds(346, 0, 172, 48);
		panel.add(lblNewLabel);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(78, 48, 698, 135);
		panel.add(scrollPane);
		table = new JTable();
		table.setFont(new Font("Times New Roman", Font.BOLD, 15));
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CUST_ID", "CUST_NAME", "CUST_ADD", "CUST_PHN"
			}
		));
		
		JButton btnNewButton = new JButton("SHOW");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL","system","password");
					Statement stmt=con.createStatement();
					ResultSet rs=stmt.executeQuery("select CUST_ID,CUST_NAME, CUST_ADD,CUST_PHN from customer1");
					table.setModel(DbUtils.resultSetToTableModel(rs));
					con.close();
					
					
				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}
			}
		});
		btnNewButton.setBounds(221, 237, 85, 21);
		panel.add(btnNewButton);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				admindashboard ad=new admindashboard();
				ad.setVisible(true);
			}
			
		});
		btnBack.setBounds(548, 237, 85, 21);
		panel.add(btnBack);
	}

	public void setVisible(boolean b) {
		frame.setVisible(b);
	}
}
