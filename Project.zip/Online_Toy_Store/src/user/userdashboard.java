package user;
import java.awt.EventQueue;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class userdashboard {
    private JFrame frame;
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    userdashboard window = new userdashboard(null, null);
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public userdashboard(String pass, String cuid) {
        initialize(cuid);
    }

    public userdashboard() {
		// TODO Auto-generated constructor stub
	}
    private void initialize(String cuid) {
        frame = new JFrame();
        frame.setBounds(100, 100, 885, 654);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.setUndecorated(true);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(82, 173, 105));
        panel.setBounds(10, 10, 827, 43);
        frame.getContentPane().add(panel);
        panel.setLayout(null);

        JLabel lblNewLabel = new JLabel("ONLINE  SHOPPING");
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setBounds(10, 10, 206, 30);
        panel.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Logout");
        lblNewLabel_1.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		ulogin u=new ulogin();
        		u.setVisible(true);
        		
        	}
        });
        lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
        lblNewLabel_1.setForeground(new Color(255, 255, 255));
        lblNewLabel_1.setBackground(new Color(255, 255, 255));
        lblNewLabel_1.setBounds(726, 19, 73, 13);
        panel.add(lblNewLabel_1);

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(53, 46, 82));
        panel_1.setForeground(new Color(24, 32, 103));
        panel_1.setBounds(10, 53, 128, 459);
        frame.getContentPane().add(panel_1);
        panel_1.setLayout(null);

        JLabel lblNewLabel_2 = new JLabel("New label");
        panel_1.add(lblNewLabel_2);

        JLabel lblNewLabel_3 = new JLabel("DASHBOARD");
        lblNewLabel_3.setForeground(new Color(255, 255, 255));
        lblNewLabel_3.setBackground(new Color(255, 255, 255));
        lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
        lblNewLabel_3.setBounds(20, 10, 128, 35);
        panel_1.add(lblNewLabel_3);

        JLabel lblNewLabel_4 = new JLabel("Purchase Details");
        lblNewLabel_4.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		PurchaseDetails pd=new PurchaseDetails();
        		pd.setVisible(true);				
        	}
        });
        lblNewLabel_4.setFont(new Font("Times New Roman", Font.PLAIN, 15));
        lblNewLabel_4.setForeground(new Color(255, 255, 255));
        lblNewLabel_4.setBounds(20, 80, 118, 24);
        panel_1.add(lblNewLabel_4);

        JPanel panel_2 = new JPanel();
        panel_2.setBounds(137, 53, 688, 459);
        frame.getContentPane().add(panel_2);
        panel_2.setLayout(null);
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL", "system", "password");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT PROD_ID, PROD_NAME, PROD_PRICE FROM product1");
            int y = 20;
            while (rs.next()) {
            	String pid = rs.getString("PROD_ID");
            	String str = "insert into orders values(orderid.nextval,'"+cuid+"','"+pid+"')";
                String productDetails = "ID: " + rs.getString("PROD_ID") +
                        " | Name: " + rs.getString("PROD_NAME") +
                        " | Price: $" + rs.getDouble("PROD_PRICE");
                JLabel productLabel = new JLabel(productDetails);
                productLabel.setFont(new Font("Arial", Font.PLAIN, 14));
                productLabel.setBounds(20, y, 600, 20);
                panel_2.add(productLabel);
                JButton buyButton = new JButton("Buy");
                buyButton.setBounds(620, y, 80, 20);
                panel_2.add(buyButton);
                buyButton.addActionListener(new ActionListener() {
        			public void actionPerformed(ActionEvent e) {
        				System.out.println(pid);
        				System.out.println(str);
        				try {
        					Class.forName("oracle.jdbc.driver.OracleDriver");
        		            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL", "system", "password");
        					Statement stmt2 = con.createStatement();
							stmt2.executeUpdate(str);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
        				JOptionPane.showMessageDialog(frame, "Ordered Successfully");
        				
        			}
                });
                y += 30;
                buyButton.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                    }
                });
            }
            con.close();
        }
        catch (SQLException e2) {
            System.out.println(e2);
        }catch (Exception e1) {
            System.out.println(e1);
        }
    }

	public void setVisible(boolean b) {
		frame.setVisible(b);	
	}
}
