package user;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.ImageIcon;
public class signup {
	private JFrame frame;
	private JTextField t1;
	private JTextField t2;
	private JTextField t4;
	private JPasswordField t5;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signup window = new signup();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public signup() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 814, 676);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(49, 206, 199));
		panel.setBounds(0, 0, 469, 629);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Sign Up");
		lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 21));
		lblNewLabel.setBounds(185, 10, 111, 32);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("User Id");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("Agency FB", Font.BOLD, 20));
		lblNewLabel_1.setBounds(63, 82, 75, 33);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel(" Name");
		lblNewLabel_2.setFont(new Font("Agency FB", Font.BOLD, 20));

		lblNewLabel_2.setBounds(63, 125, 75, 53);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Address");
		lblNewLabel_3.setFont(new Font("Agency FB", Font.BOLD, 20));
		lblNewLabel_3.setBounds(63, 188, 68, 32);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Phone");
		lblNewLabel_4.setFont(new Font("Agency FB", Font.BOLD, 20));

		lblNewLabel_4.setBounds(63, 300, 45, 31);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_6 = new JLabel("Password");
		lblNewLabel_6.setBounds(63, 350, 75, 46);
		lblNewLabel_6.setFont(new Font("Agency FB", Font.BOLD, 20));

		panel.add(lblNewLabel_6);
		
		t1 = new JTextField();
		t1.setBounds(228, 82, 231, 32);
		panel.add(t1);
		t1.setColumns(10);
		
		t2 = new JTextField();
		t2.setBounds(228, 125, 231, 41);
		panel.add(t2);
		t2.setColumns(10);
		
		JTextArea t3 = new JTextArea();
		t3.setBounds(228, 176, 231, 97);
		panel.add(t3);
		
		t4 = new JTextField();
		t4.setBounds(228, 290, 231, 41);
		panel.add(t4);
		t4.setColumns(10);
		
		t5 = new JPasswordField();
		t5.setBounds(228, 350, 231, 42);
		panel.add(t5);
		JButton btnNewButton = new JButton("Save");
		btnNewButton.setFont(new Font("Agency FB", Font.BOLD, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL","system","password");
					Statement stmt=con.createStatement();
					String cid=t1.getText();
					String cname=t2.getText();
					String cadd= t3.getText();
					String cphn=t4.getText();
					char[] passwordChars = t5.getPassword();
					String cpass = new String(passwordChars);
					String insqr="insert into customer1 values('"+cid+"' , '"+cname+"','"+cphn+"','"+cadd+"','"+cpass+"')";
					stmt.execute(insqr);
					System.out.println("Customer added successfully");
					JOptionPane.showMessageDialog(null,"Customer inserted successfully");
					t1.setText("");
					t2.setText("");
					t3.setText("");
					t4.setText("");
					ulogin u=new ulogin();
					u.setVisible(true);					//cpass.sePassword("");
					con.close();	
				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}
			}
		});
		btnNewButton.setBounds(181, 500, 85, 32);
		panel.add(btnNewButton);
		JLabel lblNewLabel_8 = new JLabel("X");
		lblNewLabel_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);			}
		});
		lblNewLabel_8.setFont(new Font("Serif", Font.BOLD, 20));
		lblNewLabel_8.setBounds(442, 14, 45, 13);
		panel.add(lblNewLabel_8);
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(49, 206, 199));
		panel_1.setBounds(463, 0, 353, 630);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		JLabel lblNewLabel_5 = new JLabel("New label");
		panel_1.add(lblNewLabel_5);
		JLabel lblNewLabel_9 = new JLabel("New label");
		lblNewLabel_9.setIcon(new ImageIcon("C:\\Users\\geena\\Downloads\\711zq8NKe2L._AC_UF894_1000_QL80_-removebg-preview.png"));
		lblNewLabel_9.setBounds(10, 10, 316, 498);
		panel_1.add(lblNewLabel_9);
	}
	public void setVisible(boolean b) {
		frame.setVisible(b);
	}
}
