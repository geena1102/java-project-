package user;
import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class PurchaseDetails {
    private JFrame frame;
    private JPanel panel;
    private JTextField textFieldCustomerId;
    private JLabel lblNewLabel_1;
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	PurchaseDetails window = new PurchaseDetails();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public PurchaseDetails() {
        initialize();
    }
    private void initialize() {
        frame = new JFrame();
        frame.getContentPane().setForeground(new Color(255, 128, 255));
        frame.setBounds(100, 100, 800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.setUndecorated(true);
        panel = new JPanel();
        panel.setBackground(new Color(84, 214, 133));
        panel.setBounds(5, 5, 770, 550);
        frame.getContentPane().add(panel);
        panel.setLayout(null);
        JLabel lblNewLabel = new JLabel("PURCHASE DETAILS");
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 15));
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setBounds(300, 10, 200, 30);
        panel.add(lblNewLabel);
        textFieldCustomerId = new JTextField();
        textFieldCustomerId.setBounds(300, 50, 150, 25);
        panel.add(textFieldCustomerId);
        textFieldCustomerId.setColumns(10);
        JButton btnFetchDetails = new JButton("Fetch Details");
        btnFetchDetails.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String customerId = textFieldCustomerId.getText();
                fetchDataFromDatabase(customerId);
            }
        });
        btnFetchDetails.setBounds(470, 50, 120, 25);
        panel.add(btnFetchDetails);
        
        lblNewLabel_1 = new JLabel("X");
        lblNewLabel_1.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		System.exit(0);
        	}
        });
        lblNewLabel_1.setForeground(new Color(255, 255, 255));
        lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
        lblNewLabel_1.setBounds(745, 10, 45, 13);
        panel.add(lblNewLabel_1);
    }

    public void setVisible(boolean b) {
        frame.setVisible(b);
    }

    private void fetchDataFromDatabase(String customerId) {
        try {     Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL", "system", "password");
            String sql = "SELECT c.cust_name, p.prod_name, p.prod_price " +
                    "FROM orders o " +
                    "JOIN customer1 c ON o.user_id = c.cust_id " +
                    "JOIN product1 p ON o.prod_id = p.prod_id " +
                    "WHERE o.user_id = ?"; // Filter by user ID

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, customerId); // Set the user ID parameter
            ResultSet rs = statement.executeQuery();
            panel.removeAll();
            int yPos = 100; // Initial y position
            int labelHeight = 20; // Height of each label
            while (rs.next()) {
                String productName = rs.getString("prod_name");
                double price = rs.getDouble("prod_price");
                String customerName = rs.getString("cust_name");
                JLabel productLabel = new JLabel("Product Name: " + productName);
                productLabel.setBounds(50, yPos, 300, labelHeight);
                panel.add(productLabel);
                JLabel priceLabel = new JLabel("Price: " + price);
                priceLabel.setBounds(50, yPos + labelHeight, 300, labelHeight);
                panel.add(priceLabel);
                JLabel customerLabel = new JLabel("Customer Name: " + customerName);
                customerLabel.setBounds(50, yPos + 2 * labelHeight, 300, labelHeight);
                panel.add(customerLabel);
                yPos += 3 * labelHeight;
            }
            panel.revalidate();
            panel.repaint();
            rs.close();
            statement.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
